package com.example.ourchord_app;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import androidx.fragment.app.Fragment;

public class midiupload_folder extends Fragment {

    private Handler mHandler;
    private Socket socket;

    private BufferedReader networkReader;
    private PrintWriter networkWriter;

    private DataOutputStream dos = null;
    private DataInputStream dis;

    private String ip = "3.34.224.145";            // IP 번호
    private int port = 9300;

    public static midiupload_folder newInstance(){
        return new midiupload_folder();
    }

    public midiupload_folder() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View mi_folder = inflater.inflate(R.layout.fragment_midiupload_folder, container, false);

        final String activity = "midiupload_folder";

        //connect_midi(activity);
        String midiList = connect_midi(activity);
        String[] server_output_midi = midiList.split("-");

        int midilist_len = server_output_midi.length;

        // 파일 이름 추가 될 리스트
        ArrayList<String> arrayList = new ArrayList<String>();
        for(int i = 0 ; i < midilist_len ; i++){
            arrayList.add(server_output_midi[i]);
        }

        ArrayAdapter<String> Adapter;
        Adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, arrayList);

        ListView listView = (ListView) mi_folder.findViewById(R.id.midi_file_list);
        listView.setAdapter(Adapter);

        return mi_folder;
    }
    String connect_midi(final String Activity) {
        mHandler = new Handler();
        Log.w("connect", "연결 하는중");
        final String[] update_midi_list = new String[1];
        Thread checkUpdate = new Thread() {
            public void run() {
                try {
                    socket = new Socket(ip, port);
                    Log.w("서버 접속됨", "서버 접속됨");
                } catch (IOException e1) {
                    Log.w("서버접속못함", "서버접속못함");
                    e1.printStackTrace();
                }
                try {
                    dos = new DataOutputStream(socket.getOutputStream());
                    dis = new DataInputStream(socket.getInputStream());

                    // input에 받을꺼 넣어짐
                    Log.w("Activity 확인", Activity);
                    String checkpoint = "+";
                    String PDFInfo = Activity;
                    dos.writeBytes(PDFInfo);
                    dos.writeBytes(checkpoint);

                    // 파일 이름 최대 길이 설정
                    int file_len = 50;
                    byte[] m_s_a_data = new byte[file_len];

                    dis.read(m_s_a_data, 0, file_len);

                    String update_midi_list_name = new String(m_s_a_data, "UTF-8");
                    System.out.println("midi-list : " + update_midi_list_name);
                    update_midi_list[0] = update_midi_list_name;

                } catch (IOException e) {
                    e.printStackTrace();
                    Log.w("버퍼", "버퍼생성 잘못됨");
                }
                Log.w("버퍼", "버퍼생성 잘됨");
            }
        };
        checkUpdate.start();
        Log.w("버퍼", "check");
        try{
            checkUpdate.join();
        }catch (Exception e) {
            e.printStackTrace();
        }
        return update_midi_list[0];
    }
}
