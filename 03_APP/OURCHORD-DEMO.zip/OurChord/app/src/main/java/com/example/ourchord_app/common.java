package com.example.ourchord_app;

import android.app.Application;

import java.util.List;

public class common extends Application {

    //private String global_IP = "3.34.224.145";           // 새로운 IP
    private String global_IP = "13.125.160.38";            // 느린 IP 번호
    private String user_name = "";
    private String pdf_list;
    private List<String> pdf_array_list;

    public String getPdf_list(){
        return pdf_list;
    }
    public void setGlobal_IP(String pdf_list){
        this.pdf_list = pdf_list;
    }

}
